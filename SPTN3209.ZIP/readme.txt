         SimpTerm Version 0.9.4 - WINSOCK Edition

 A telnet/rlogin client with file download and KANJI display support
 Copyright  (c)  JIANQING HU  1993, 1994, 1995.  All rights reserved.
 Author: JIANQING HU, 470 W 27th ST. Chicago IL 60616 (312) 326-0200

 This is the network version of SimpTerm with telnet, rlogin support
 over a winsock 1.1 compatible TCP/IP stack under MS Windows.

 The 32 bit version SPTNET32.EXE works with NT 3.1 and up, Windows 95
 and Windows 3.1with win32s 1.15 and up

 The 16 bit version SPTNET16.EXE works with Windows 3.1 and up
 

New in this version
===================

  Windows 95 style scroll bar and tool bar

       This requires Windows 95, but the program will run on Windows 3.1
       and up.  The toolbar needs 16 or 32 bit commctrl.dll, so if you 
       have only Windows 3.1 or NT 3.1, the toolbar may not show up.  
       
  Kermit and Zmodem download with autodetection

       Just start the remote kermit or zmodem program and SimpTerm will 
       enter download mode once it sees the remote end want to send a file

  Display BIG5 and HZ code at the same time

       This version of SimpTerm will decode Chinese text in the screen 
       buffer so makes it possible for you to read HZ and BIG5 or 
       HZ and GB at the same time. 
       
  Huge scroll back buffer 
  
       Anywhere between 200 to 32760 lines configurable. So be ready to
       have plenty of RAM or SWAP File.
  

Command Line Arguments
======================

    Format

    sptnet16 [-d] [-f config-file] [-w] [host-name [port] [-l login-name]]

    For 32 bit version, use sptnet32 

    where anything in [ ] is optional

          -d  Bring up the Remote Connection dialog after start-up
              ignored if used with a host name

          -f config-file

              Use config-file instead of default as configuration file
              If the named file does not exist, the program will produce
              one in that name with default settings.

              For 16 bit version, the default configuration file is
              sptnet16.ini. For 32 bit version, sptnet32.ini

              example: sptnet16 -f foo.cfg

          -w  Disable the telnet window size and teminal type negotiation
              ignored when use the program for other purpose

          host-name

              Specify a host name or IP address

              example: sptnet16 foo.bar.com
                       sptnet16 192.0.2.1

          port

              Specify a service name or port number.
              Must follow a host name or address

              For rlogin, the service name IS login
              
              If this field is missing and a host
              is specified, the telnet is assumed

              example
                   sptnet16 foo.bar.com login 
                   sptnet16 foo.bar.com 513 
                    - rlogin to foo.bar.com

                   sptnet16 foo.bar.com daytime 
                    - connect to foo.bar.com's date server

          -l login-name

             Provide a login name or a user name when doing
             rlogin, finger


              
Make a connection
=================

    If you start the program with no command line argument,
    You use the Remote Connection dialog to fill-in required
    information. 

    The Login Name filed could be use to specify a login name
    for rlogin or a user name for finger

    This field will be IGNORED by other services


View Chinese Text
=================

    To see Chinese text, you may either use a Chinese Windows,
    Chinese-enable software for Windows or the internal KANJI
    driver of SimpTerm.

    The intenal driver is especially useful when you 

      -don't want to install a huge Chinese system
      
      -don't lucky enough to have a video driver to
       work properly with those Chinese systems

      -want to view more than one type of Chinese text

    To enable this driver, you check the Use Bitmap Font
    in the View menu and install a set of Chinese Bitmap
    fonts

    To disable this driver, you uncheck the Use Bitmap Font
    in the  View menu OR remove the Chinese font

    It is possible for you to use the internal driver
    for one type of Chinese text only. In this case,
    you just install the font for this type of text.
 
    Note: HZ and GB filter use the same GB font
          so to use internal driver for HZ only
          you can't choose GB and HZ at the same time.

    
Install Chinese font files
==========================

    The internal Chinese font driver read KFMGR.INI
    for font information. 

    This is an ASCII file. You can use DOS edit or 
    Windows notepad to change it.

    File Format:

    [fonts]
    gbfont=GB-font-file-name
    big5font=BIG5-font-file-name

    where
        GB-font-file-name specifies a GB encoded bitmap font
        BIG5-font-file-name specifies a BIG5 encoded bitmap font

    example

    [fonts]
    gbfont=c:\fonts\kanji\cclib.16
    big5font=c:\fonts\kanji\chinese.16

    Note: the driver can't use bitmap font with a larger than a 6X16 cell
          This package contains NO bitmap font files. You have to get
          it somewhere on the internet with Chinese related software.
          Try ftp.ifcss.org or cnd.org

 
Short Cut Keys
==============

   ALT-R Bring up the Receive File dialog box
   ALT-K Start Kermit Receive
   ALT-Z Start Zmodem Receive
   ALT-Y Start Ymodem Receive
   ALT-G Start Ymodem G Receive

   ALT-D Make a new connection

   CTRL-INS Copy selected text to clipboard
   SHIFT-INS Paste clipboard text to terminal window

Using Mouse
===========

   The left mouse button is configured like other Windows program
   that can be used to select text in the terminal window. However
   when double click the left mouse button, the text under mouse pointer
   will be send to the remote computer. The right mouse button, when clicked
   will send an enter to the remote computer when there is no text selected.
   Otherwise, it will send the selected text to the remote computer.



Bugs and Limitations
====================

File download may not work with your host computer. 
If you are lucky enough to have them work, the throughput, 
in most cases, will be slower than ftp, which is by design for a 
TCP/IP connection.  The reason is that a tcp/ip connection
add a lot of information on a packet and doing acknowlegement
for each packet. So even the stream protocols like zmodem, ymodem-G
won't help.

Rlogin will not work if you use TIA or Slirp, which provide a dummy
internet address over a SLIP/PPP connection.

32 bit version may cause a GPF when you use Microsoft mosue with their
version 9.0 POINTER.EXE/POINTER.DLL under WIN32S.  But after the error
box is closed, the 32 bit version will work just normally.
Upgrade to 9.01 (ftp.microsoft.com)

When displaying Chinese text in GB or BIG5 mode, the text may not be
broken at proper place when there is no line break in the original
encoded Chinese text. For example the HXWZ electronics magzines. Use
a Chinese text viewer at the remote end to improve the situation.


Contact the Author
==================

I will be more than happy to hear from you for any suggestion, comment
or bug report. I can be reached at

JIANQING HU
470 W. 27st Street
Chicago, IL 60616
USA

Telephone: (01) 312-326-0200

Internet: thssjyh@iitmax.acc.iit.edu or 
          hujianq@xtreme2.acc.iit.edu


Donations
=========

   If you like this program, you may make some donations
   to further support its future develpmonet.

   Money is always welcomed but the following may serve
   the purpose equally well:

        Post Cards

           from where you live/work and possibly with
           how you like/dislike the program

        Jeep parts and Off-Road things

           I drive a 95 Jeep Wrangler I-6 and am looking for
           any interesting things for this type of trucks
           like tops, soft doors, manuals, etc.

        Electronics Stuff

           I made my first radio at age of 10 and it was
           my hobby of choice before I wrote programs.
           So I am interested in CBs, radios, scanners 
           of any kind in any conditions. 

        
        Camera Parts

           Anything for Canon A-1 manual SLR

        
